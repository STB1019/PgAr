package SommaMultipli;

import LogTime.*;

public class MainSommaMultipli {

	final static int NUM = 3;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int minoriDi[] = { 10, 100, 1000 }; // utilizzo un array per
											// automatizzare l'intera operazione
		int somme[] = new int[NUM];
		int i;
		int j;
		int somma = 0;
		LogTime logtime = new LogTime();

		logtime.getTime();
		for (i = 0; i < NUM; i++) {
			for (j = 0; j < minoriDi[i]; j++) {
				if (j % 5 == 0 || j % 3 == 0) { // algoritmo troppo lento-->
												// modifichero con Euclide
					somma = somma + j;
				}
			}
			somme[i] = somma;
			somma = 0;
		}

		logtime.getTime();

		for (i = 0; i < NUM; i++) {
			System.out.println(somme[i]);

		}

		logtime.getDelta(LogTime.MILLI);
		logtime.getDelta(LogTime.SECOND);
		logtime.getDelta(LogTime.MINUTE);

	}
}
