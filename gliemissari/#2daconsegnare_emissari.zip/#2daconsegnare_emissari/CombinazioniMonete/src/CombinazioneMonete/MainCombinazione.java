package CombinazioneMonete;

public class MainCombinazione {

	public static void main(String[] args) {

		int elencoValori[] = { 100, 200, 250 };
		int elencoNumeri[] = Monete.getElencoMonete();
		Combinazioni temp=new Combinazioni();
		ElencoCombinazioni elenco = new ElencoCombinazioni();
		
		int k = 0;
		
		

	}

}
