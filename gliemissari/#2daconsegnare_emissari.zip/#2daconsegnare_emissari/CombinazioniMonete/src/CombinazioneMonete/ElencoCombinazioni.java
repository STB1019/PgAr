package CombinazioneMonete;

import java.util.Vector;

public class ElencoCombinazioni {

	Vector<Combinazioni> elencoCombinazioni = new Vector<>();
	
	public void aggiungiCombinazione(Combinazioni comb){
		elencoCombinazioni.add(comb);
	}
	
    public void stampaCombinazioni(){
    	for(int i=0;i<elencoCombinazioni.size();i++){
    		System.out.println(elencoCombinazioni.get(i));
    	}
    }
    
    public Vector<Combinazioni> getElencoCombinazioni(){
    	return elencoCombinazioni;
    }
    
    
    
    
}
