package CombinazioneMonete;

public class Monete {

	static final int UN_PENNY = 1;
	static final int DUE_PENNY = 2;
	static final int CINQUE_PENNY = 5;
	static final int DIECI_PENNY = 10;
	static final int VENTI_PENNY = 20;
	static final int CINQUANTA_PENNY = 50;
	static final int CENTO_PENNY = 100;
	static final int DUECENTO_PENNY = 200;

	static int elencoMonete[] ={UN_PENNY,DUE_PENNY , CINQUE_PENNY,  DIECI_PENNY ,VENTI_PENNY ,
			CINQUANTA_PENNY,CENTO_PENNY ,DUECENTO_PENNY};
	
	static public int[] getElencoMonete(){
		return elencoMonete;
		
	}

	
}
