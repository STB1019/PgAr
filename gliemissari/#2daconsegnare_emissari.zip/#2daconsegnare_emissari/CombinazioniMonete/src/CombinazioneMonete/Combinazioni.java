package CombinazioneMonete;

public class Combinazioni {
	static final String PIU = "+";
	
    private int num1p = 0;
	private int num2p = 0;
	private int num5p = 0;
	private int num10p = 0;
	private int num20p = 0;
	private int num50p = 0;
	private int num100p = 0;
	private int num200p = 0;

	public int getNum1p() {
		return num1p;
	}

	public void setNum1p(int num1p) {
		this.num1p = num1p;
	}

	public int getNum2p() {
		return num2p;
	}

	public void setNum2p(int num2p) {
		this.num2p = num2p;
	}

	public int getNum5p() {
		return num5p;
	}

	public void setNum5p(int num5p) {
		this.num5p = num5p;
	}

	public int getNum10p() {
		return num10p;
	}

	public void setNum10p(int num10p) {
		this.num10p = num10p;
	}

	public int getNum20p() {
		return num20p;
	}

	public void setNum20p(int num20p) {
		this.num20p = num20p;
	}

	public int getNum50p() {
		return num50p;
	}

	public void setNum50p(int num50p) {
		this.num50p = num50p;
	}

	public int getNum100p() {
		return num100p;
	}

	public void setNum100p(int num100p) {
		this.num100p = num100p;
	}

	public int getNum200p() {
		return num200p;
	}

	public void setNum200p(int num200p) {
		this.num200p = num200p;
	}

	@Override
	public String toString() {
		return num1p + PIU + num2p + PIU + num5p + PIU + num10p + PIU + num20p + PIU + num50p + PIU + num100p + PIU
				+ num200p;

	}
}
