package Ordinamento;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.Vector;
import LogTime.LogTime;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


import leggi_valori.LeggiStringhe;

public class MainOrdinaGrandiNumeri {

	static final String CORNICE = "*****************************************************";
	static Vector<Numero> elencoNumeri = new Vector<Numero>();
	static Vector<Numero> ordinato = new Vector<>();
	static Numero temp = null;
	static final String MAX = "Il massimo numero dell' elenco e': ";
	static final String MIN = "Il minore numero dell' elenco e': ";
	static final String MEDIANA = "LA mediana e': ";
	static final String ERROREMEDIANA = "Vettore vuoto";

	public static void main(String[] args) throws IOException, XMLStreamException {

        LogTime logtime= new LogTime();
		
		leggiFile();

		stampaElencoNumeri(elencoNumeri);

		stampa_valori.StampaValori.stampaStringACapo(CORNICE);

		logtime.getTime();
		ordinaNumeri();
        logtime.getTime();
		stampaElencoNumeri(ordinato);

		stampa_valori.StampaValori.stampaStringACapo(MAX + getMax());

		stampa_valori.StampaValori.stampaStringACapo(MIN + getMin());

		stampa_valori.StampaValori.stampaStringACapo(MEDIANA + mediana(ordinato));
		
		// stampo il tempo di esecuzione dell'ordinamento dei numeri
		
		logtime.getDelta(LogTime.MILLI);
		logtime.getDelta(LogTime.SECOND);
		logtime.getDelta(LogTime.MINUTE);

	}

	/**
	 * legge il file in input e crea l'elenco di numeri da ordinare
	 * 
	 * @throws IOException
	 * @throws XMLStreamException
	 */

	private static void leggiFile() throws IOException, XMLStreamException {

		File file;
		int base = 0, esponente = 0;
		String letto = null;

		String nomeFile = "problem.xml";
	    nomeFile = LeggiStringhe.leggiStringa("Inserisci nome del file");
		String daEliminare = null;

		try {
			file = new File(nomeFile);
		} catch (Exception e) {
			System.out.println("File at " + nomeFile + " is not avaiable or correctly patthed");
			return;
		}

		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader reader = factory.createXMLStreamReader(new FileInputStream(nomeFile));

		while (reader.hasNext()) {
			switch (reader.next()) {
			case XMLStreamConstants.START_DOCUMENT:

				System.out.println("Start reading Doc");
				break;

			case XMLStreamConstants.START_ELEMENT:

				letto = reader.getLocalName();

				if ("desc".equals(letto)) {
					reader.next();
				}
				
				if ("candiate".equals(reader.getLocalName())) {
				

					if ("b".equals(reader.getAttributeName(0).toString())) {
						base = Integer.parseInt(reader.getAttributeValue(0));
					}
					if ("e".equals(reader.getAttributeName(1).toString())) {
						esponente = Integer.parseInt(reader.getAttributeValue(1));
					}

					temp = new Numero(base, esponente);
					elencoNumeri.add(temp);
					temp = null;
				}

				break;
			case XMLStreamConstants.CHARACTERS:

				if (reader.getText().trim().length() > 0) {
					daEliminare = reader.getText().trim();

				}

				break;

			case XMLStreamConstants.END_ELEMENT:

				break;
			case XMLStreamConstants.END_DOCUMENT:
				System.out.println("End reading Doc");
				break;

			} // switch
		} // while

	}// metodo

	public static void ordinaNumeri() {

		Vector<Numero> daOrdinare = new Vector<>();

		for (int i = 0; i < elencoNumeri.size(); i++) {
			daOrdinare.add(i, elencoNumeri.get((i)));
		}

		Numero max = null;
		int n = daOrdinare.size();

		/**
		 * 1) alortitmo temporaneo. da sostituire con un quick sort --> questo
		 * fa schifo
		 * 
		 * 2) algoritmo migliorato, ma non mi convince lo stesso sarebbe da
		 * testar con numeri noti e bassi dopo lo faccio--> tesato con valori
		 * bassi e noti, correggere errore con debugger algoritmo quasi corretto
		 * 
		 * 3) devo ancora perfezionarlo: piccolo diguido con potenze base bassa
		 * 
		 */

		while (n != 0) {
			max = daOrdinare.get(0);
			for (int i = 0; i < n; i++) {

				Numero temp = daOrdinare.get(i);

				if (daOrdinare.get(i).getBase() == max.getBase()) {
					if (daOrdinare.get(i).getEsponente() > max.getEsponente()) {
						max = daOrdinare.get(i);
					}
				} else {
					if (daOrdinare.get(i).getBase() > max.getBase()) {
						if (daOrdinare.get(i).getEsponente() == max.getEsponente()) {
							max = daOrdinare.get(i);
						} else {
							if (daOrdinare.get(i).getEsponente() > max.getEsponente()) {
								max = daOrdinare.get(i);
							}
						}
					} else {
						if (daOrdinare.get(i).getBase() < max.getBase()) {
							if (daOrdinare.get(i).getEsponente() > max.getEsponente()) {
								max = daOrdinare.get(i);
							}
						}
					}

				}

			} // for
			ordinato.add(max);
			daOrdinare.remove(max);
			max = null;
			n--;
		} // while

	}

	public static Numero getMax() {
		return ordinato.size() > 0 ? ordinato.get(0) : null;
	}

	public static Numero getMin() {
		return ordinato.size() > 0 ? ordinato.get(ordinato.size() - 1) : null;
	}

	public static Numero mediana(Vector<Numero> vettore) {
		Numero mediana = null;
		int indice = -1;

		int n = vettore.size();
		if (n == 0) {
			stampa_valori.StampaValori.stampaStringACapo(ERROREMEDIANA);
		}
		if (n % 2 == 0) {
			indice = ((n / 2) - 1);
		} else {
			indice = ((n / 2));
		}

		return vettore.get(indice);
	}

	public static void stampaElencoNumeri(Vector<Numero> daStampare) {
		int index = -1;
		for (int i = 0; i < daStampare.size(); i++) {
			index = 1 + i;
			System.out.println(index + " " + daStampare.get(i));
		}

	}
}
