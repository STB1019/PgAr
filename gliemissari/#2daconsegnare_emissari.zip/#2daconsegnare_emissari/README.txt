ho aggiunto anche la classe myutility che ho usato negli esercizi nel caso ci fossero problemi
