package stampa_valori;

public class StampaValori {
	
	/**
	 * stampa una String andando a capo dopo la stringa
	 * @param str stringa che indica di inserire un dato
	 * @return
	 */
	
	public static void stampaStringACapo(String str){
		System.out.println(str);
	}
	/**
	 *  stampa una String andando non andando la stringa
	 * @param str stringa che indica di inserire un dato
	 * @return
	 */
	
	public static void stampaStringNonACapo(String str){
		System.out.print(str);
	}
	
}
