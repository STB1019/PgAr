package leggi_valori;

import java.util.Scanner;

public class LeggiNumeri {
	final static Scanner sc= new Scanner (System.in);
	

	/**
	 *  permette l'inserimento di un numero intero andando a capo dopo la stringa
	 * @param st stringa che indica di inserire un dato
	 * @return  int
	 */
	public static int leggiIntero(String str){
		int n=0;
		System.out.println(str);
		n=sc.nextInt();
		return n;
	}
	/**
	 *  permette l'inserimento di un numero intero non andando a capo dopo la stringa
	 * @param st stringa che indica di inserire un dato
	 * @return int
	 */
	
	public static int leggiInteroNonACapo(String str){
		int n=0;
		System.out.print(str);
		n=sc.nextInt();
		return n;
	}
	
}
