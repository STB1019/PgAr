package enoteca;

public class ConvertiValute {

	static final float TASSO_EURO_DOLLARO=(float) 0.9199;
	static final float TASSO_DOLLARO_PER_EURO=(float) 1.0871;	
	
	static float dollariPerEuro(float somma){
		return (somma*TASSO_EURO_DOLLARO);
	}
	
	static float euroPerDollaro(float somma){
		return (somma*TASSO_DOLLARO_PER_EURO);
	}


	
	
}
