package enoteca;

import java.util.Vector;

import stampa_valori.StampaValori;

public class ElencoVini {

	Vector<Vino> elencoVini = new Vector<>();

	public void aggiungiVino(Vino vino) {
		elencoVini.add(vino);
	}

	public Vector<Vino> getElencoVini() {
		return elencoVini;
	}

	public void getBottigliePerProduttore() {
		String produttore = null;
		int n = elencoVini.size(), tot = 0;
		for (int i = 0; i < n; i++) {
			produttore = elencoVini.get(i).getProduttore();
			tot = 0;
			for (int j = 0; j < n; j++) {
				if (elencoVini.get(j).getProduttore().equals(produttore)) {
					tot = tot + elencoVini.get(j).getCont();
				}
			}
			System.out.println("Il produttore " + produttore + " ha fornito " + tot + " bttiglie");

		}

	}

	public void ammontarePossibiliGuadagni(String valuta) {
		float tot = 0;
		int n, i;
		n = elencoVini.size();
		switch (valuta) {
		case "�":
			for (i = 0; i < n; i++) {
				if (elencoVini.get(i).getTipoValuta().equals(valuta)) {
					tot = elencoVini.get(i).getPrezzo() + tot;
				} else {
					tot = ConvertiValute.dollariPerEuro(elencoVini.get(i).getPrezzo()) + tot;
				}
			}
			break;
		case "$":
			for (i = 0; i < n; i++) {
				if (elencoVini.get(i).getTipoValuta().equals(valuta)) {
					tot = elencoVini.get(i).getPrezzo() + tot;
				} else {
					tot = ConvertiValute.euroPerDollaro(elencoVini.get(i).getPrezzo()) + tot;
				}
			}
			break;
		}

		System.out.println("Ammontare: " + tot + " " + valuta);

	}

	public void vinitraDueData(int data1, int data2) {
		Vector<Vino> dastampare = new Vector<>();
		int n = elencoVini.size();
		for (int i = 0; i < n; i++) {
			if (elencoVini.get(i).getAnnoProduzione() >= data1 && elencoVini.get(i).getAnnoProduzione() <= data2) {
				dastampare.add(elencoVini.get(i));
			}
		}
		if (dastampare.size() == 0) {
            StampaValori.stampaStringACapo("Non sono presenti vini");
		} else {
			for (Vino davisualizzare : dastampare) {
				System.out.println(davisualizzare);
			}
		}
	}

	public void stampaElencoVini() {
		for (int i = 0; i < elencoVini.size(); i++) {
			System.out.println(elencoVini.get(i));
		}
	}

	// stampare la quantit� di bottoglie per ogno vino --> metodo stampa
	// inventario
	public void stampaInventario() {
		for (int i = 0; i < elencoVini.size(); i++) {
			System.out.println(elencoVini.get(i).getNomeVino() + ": " + elencoVini.get(i).getCont());
		}
	}

}
