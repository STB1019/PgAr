package enoteca;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import leggi_valori.LeggiNumeri;
import leggi_valori.LeggiStringhe;
import stampa_valori.StampaValori;

public class EnotecaMain {

	final static String INSERISCIVALUTA = "Insersci la valuta";
	final static String DATA1 = "Inserisci la prima data";
	final static String DATA2 = "Insersci la seconda data";
	final static String LEGGIFILE = "Inserisce il nome del file da legere";
	final static String ERRORE_NEL_FILE = "estensione non presente";
	final static String CORNICE = "*************************************************************";
	final static String ACAPO = "\n";
	final static String INTESTAZIONE="Enoteca da Paolo Bitta";
	final static String INTESTAZIONEMAIUSC=INTESTAZIONE.toUpperCase();
	final static String MENU = CORNICE +ACAPO+INTESTAZIONEMAIUSC+ ACAPO + "1 Stampare la lista dei vini contenuti nel magazzino" + ACAPO
			+ "2 Stampare la quantit� di bottiglie per ogni Vino" + ACAPO
			+ "3 Stampare la quantit� di Bottiglie per ogni Produttore" + ACAPO
			+ "4 Stampare il possibile guadagno in Multi-valuta" + ACAPO
			+ "5 Data una certa fascia di Annata stampare tutti i vini" + ACAPO + "6 per terminare" 
			+ ACAPO+CORNICE;

	static ElencoVini magazzino = new ElencoVini();

	public static void main(String[] args) throws FileNotFoundException, XMLStreamException {

		int scelta = 0;
		String valuta = null;
		boolean ciclo = true;
		int data1 = 0, data2 = 0;
		String filename;

		filename = LeggiStringhe.leggiStringa(LEGGIFILE);

		// conrtrollo se � presente l'estensione del file

		if (filename.indexOf(".") == -1) {
			
			filename = filename + ".xml";
		}

		leggiFile(filename);

		// menu
		stampaMenu(MENU);

		while (ciclo) {
			// controllo la correttezza dell'acquisizione
			do{
			scelta = LeggiNumeri.leggiIntero("inserisci scelta");
			}while(!(scelta >0 && scelta <7) );
			switch (scelta) {
			case 1:
				magazzino.stampaElencoVini();
				break;
			case 2:
				magazzino.stampaInventario();
				break;
			case 3:
				magazzino.getBottigliePerProduttore();
				break;
			case 4:
				do{
					valuta = LeggiStringhe.leggiStringa(INSERISCIVALUTA);
					if(valuta .equals("$")|| valuta.equals("�")){
						break;
					}
				} while (true);
				magazzino.ammontarePossibiliGuadagni(valuta);
				break;
			case 5:
				do {
					data1 = LeggiNumeri.leggiIntero(DATA1);
					data2 = LeggiNumeri.leggiIntero(DATA2);	
				} while (!(data1 < data2));
				magazzino.vinitraDueData(data1, data2);
				break;
			case 6:
				
				ciclo = false;
				break;

			}// chiudo switch
		} // chiudo while

	}// chiudo main

	public static void leggiFile(String filename) throws FileNotFoundException, XMLStreamException {

		Vino temp = null;
		File file;
		String valuta = null;
		String letto = null, dato = null;

		try {
			file = new File(filename);
		} catch (Exception e) {
			System.out.println("File at " + filename + " is not avaiable or correctly patthed");
			return;
		}
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader reader = factory.createXMLStreamReader(new FileInputStream(filename));

		while (reader.hasNext()) {
			switch (reader.next()) {
			case XMLStreamConstants.START_DOCUMENT:

				System.out.println("Start reading Doc");
				break;

			case XMLStreamConstants.START_ELEMENT:
				letto = reader.getLocalName();
				if ("wines".equals(letto)) {

					magazzino = new ElencoVini();
					// System.out.println("creo l'elenco dei vini");

				}
				if ("wine".equals(letto)) {
					temp = new Vino();
					// System.out.println("creo un vino");
				}
				if ("price".equals(letto)) {
					QName l = reader.getAttributeName(0);
					if ("val".equals(l.toString())) {
						valuta = reader.getAttributeValue(0);
					}
				}

				break;
			case XMLStreamConstants.CHARACTERS:
				if (reader.getText().trim().length() > 0) {
					dato = reader.getText().trim();
					}

				break;

			case XMLStreamConstants.END_ELEMENT:
				switch (reader.getLocalName()) {
				case "wines":
					
					break;
				case "wine":
					magazzino.aggiungiVino(temp);
					temp=null;
					break;
				case "name":
					if (!dato.equals("Enoteca")) {
						temp.setNomeVino(dato);
						// System.out.println(dato);
					}
					break;
				case "price":
					temp.setTipoValuta(valuta);
					temp.setPrezzo(Float.parseFloat(dato));
					break;
				case "cont":
					temp.setCont(Integer.parseInt(dato));
					break;
				case "date":
					temp.setAnnoProduzione(Integer.parseInt(dato));
					break;
				case "geo":
					temp.setOrigine(dato);
					break;

				case "farmer":
					temp.setProduttore(dato);
					break;
				}
				break;
			case XMLStreamConstants.END_DOCUMENT:
				System.out.println("End reading Doc");
				break;

			} // switch
		} // while

	}// FINE leggiFile()

	public static void stampaMenu(String str) {
		StampaValori.stampaStringACapo(str);

	}

}
