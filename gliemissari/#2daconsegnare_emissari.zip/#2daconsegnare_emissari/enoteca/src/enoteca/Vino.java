package enoteca;

public class Vino {
    
	final static String SPAZIO=" ";
	
	private String nomeVino;
	private int annoProduzione;
	private float prezzo;
	private String tipoValuta;
	private String produttore;
	private int cont;
	private String origine;
	
	
	
	public String getOrigine() {
		return origine;
	}
	public void setOrigine(String origine) {
		this.origine = origine;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public String getNomeVino() {
		return nomeVino;
	}
	public int getAnnoProduzione() {
		return annoProduzione;
	}
	public void setAnnoProduzione(int annoProduzione) {
		this.annoProduzione = annoProduzione;
	}
	public float getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}
	public String getTipoValuta() {
		return tipoValuta;
	}
	public void setTipoValuta(String tipoValuta) {
		this.tipoValuta = tipoValuta;
	}
	public String getProduttore() {
		return produttore;
	}
	public void setProduttore(String produttore) {
		this.produttore = produttore;
	}
	public void setNomeVino(String nomeVino) {
		this.nomeVino = nomeVino;
	}
	
	@Override
	public String toString() {
		return nomeVino+SPAZIO+"\n"
				+ "costa "+prezzo+SPAZIO+tipoValuta+"\n"
						+ "prodotto in "+origine+SPAZIO+"da "+produttore+SPAZIO+"\nnel "+annoProduzione+"\n";
	}
	
	
	
	
}
